// Import package dan library yang diperlukan
import 'dart:convert'; // Untuk decode/encode data JSON
import 'dart:ui'; // Untuk efek UI seperti blur
import 'package:flutter/material.dart'; // Komponen UI Flutter
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart'; // Layout grid tidak simetris
import 'package:google_fonts/google_fonts.dart'; // Font dari Google Fonts
import 'package:shared_preferences/shared_preferences.dart'; // Penyimpanan lokal data sederhana
import 'package:http/http.dart' as http; // Melakukan request HTTP

// MODEL DATA DESTINASI
class DestinasiModel {
  final int id; // ID unik untuk tiap destinasi
  final String nama; // Nama destinasi
  final String deskripsi; // Deskripsi destinasi
  final String gambar; // URL atau path gambar
  final String kategori; // Kategori (gunung, pantai, dll)

  DestinasiModel({
    required this.id,
    required this.nama,
    required this.deskripsi,
    required this.gambar,
    required this.kategori,
  });

  // Factory method untuk parsing JSON menjadi objek
  factory DestinasiModel.fromJson(Map<String, dynamic> json) {
    return DestinasiModel(
      id: int.tryParse(json['id'].toString()) ?? 0, // Cegah error kalau id null atau bukan int
      nama: json['nama'] ?? '', // Default ke string kosong jika null
      deskripsi: json['deskripsi'] ?? '',
      gambar: json['gambar'] ?? '',
      kategori: json['kategori'] ?? '',
    );
  }
}

// PAGE DESTINASI
class DestinasiPage extends StatefulWidget {
  const DestinasiPage({super.key});

  @override
  State<DestinasiPage> createState() => _DestinasiPageState();
}

class _DestinasiPageState extends State<DestinasiPage> {
  List<DestinasiModel> destinasiList = []; // Daftar destinasi dari API
  bool _isLoading = true; // Status loading awal

  // Fungsi ambil data destinasi dari API
  Future<void> fetchDestinasi() async {
    try {
      final response = await http.get(Uri.parse(
          'http://zaa.fortunis11.com/NatureNest-API/API-Destinasi/get_destinasi.php')); // Ambil data dari API

      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body); // Decode JSON

        if (decoded is List) {
          setState(() {
            destinasiList =
                decoded.map((e) => DestinasiModel.fromJson(e)).toList(); // Mapping ke list model
            _isLoading = false; // Matikan loading
          });
        } else {
          throw Exception("Format JSON tidak sesuai (bukan List)");
        }
      } else {
        throw Exception('Gagal mengambil data destinasi');
      }
    } catch (e) {
      setState(() {
        _isLoading = false; // Tetap matikan loading walau error
      });
      print("Error: $e");
    }
  }

  // Fungsi tambah ke wishlist
  Future<void> addToWishlist(int destinationId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance(); // Ambil penyimpanan lokal
    final userId = prefs.getString('user_id'); // Ambil ID user
    final url = Uri.parse(
        'http://zaa.fortunis11.com/NatureNest-API/API-Wishlist/add_wishlist.php'); // API tambah wishlist

    final response = await http.post(url, body: {
      'user_id': userId,
      'destination_id': destinationId.toString(),
      'note': 'Ingin dikunjungi',
    });

    String message = response.statusCode == 200
        ? 'Berhasil ditambahkan ke wishlist'
        : 'Gagal menambahkan ke wishlist';

    // Tampilkan pesan sebagai dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        backgroundColor: Colors.white,
        title: const Text('Pesan'),
        content: Text(message),
        actions: [
          TextButton(
            child: const Text('OK'),
            onPressed: () => Navigator.of(context).pop(), // Tutup dialog
          ),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    fetchDestinasi(); // Panggil fetch saat halaman dimuat
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF2EA), // Background hijau muda
      appBar: AppBar(
        title: Text(
          'Destinasi Wisata',
          style: GoogleFonts.poppins(
              fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF8F957B), // Hijau tua
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)), // AppBar rounded
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator()) // Tampilkan loading
          : Padding(
              padding: const EdgeInsets.all(12.0),
              child: MasonryGridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                itemCount: destinasiList.length,
                itemBuilder: (context, index) {
                  final destinasi = destinasiList[index];
                  return buildDestinasiCard(destinasi); // Buat kartu
                },
              ),
            ),
    );
  }

  // Widget kartu destinasi
  Widget buildDestinasiCard(DestinasiModel destinasi) {
    final isOnlineImage = destinasi.gambar.startsWith('http'); // Cek apakah gambar online

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => DetailPage(destinasi: destinasi)), // Pindah ke halaman detail
        );
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(3, 6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Hero(
                    tag: 'destinasi_${destinasi.id}',
                    child: isOnlineImage
                        ? Image.network(
                            destinasi.gambar,
                            height: 160,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          )
                        : Image.asset(
                            destinasi.gambar,
                            height: 160,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                  ),
                  Positioned(
                    top: 12,
                    right: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(
                        destinasi.kategori,
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          color: Colors.white,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 12,
                    left: 12,
                    child: GestureDetector(
                      onTap: () => addToWishlist(destinasi.id), // Tambah wishlist saat diklik
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.6),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 4,
                              offset: const Offset(2, 2),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.favorite_border,
                            color: Colors.red),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      destinasi.nama,
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        const Icon(Icons.location_on,
                            size: 14, color: Colors.black54),
                        const SizedBox(width: 4),
                        Text(
                          'Indonesia', // Default lokasi
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: Colors.black54,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      destinasi.deskripsi,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.poppins(
                        fontSize: 13,
                        color: Colors.black87,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// HALAMAN DETAIL DESTINASI
class DetailPage extends StatelessWidget {
  final DestinasiModel destinasi;
  const DetailPage({super.key, required this.destinasi});

  @override
  Widget build(BuildContext context) {
    final isOnlineImage = destinasi.gambar.startsWith('http'); // Cek gambar online

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: const Color(0xFFEFF2EA),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(
        children: [
          Hero(
            tag: 'destinasi_${destinasi.id}',
            child: isOnlineImage
                ? Image.network(
                    destinasi.gambar,
                    height: double.infinity,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  )
                : Image.asset(
                    destinasi.gambar,
                    height: double.infinity,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
          ),
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              color: Colors.black.withOpacity(0.35), // Overlay gelap
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              margin: const EdgeInsets.all(24),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.85),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      destinasi.nama,
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.category,
                            size: 16, color: Colors.green),
                        const SizedBox(width: 6),
                        Text(
                          destinasi.kategori,
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            color: Colors.black87,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Text(
                      destinasi.deskripsi,
                      style: GoogleFonts.poppins(
                        fontSize: 15,
                        color: Colors.black87,
                        height: 1.6,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
