import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';

class UlasanPage extends StatefulWidget {
  const UlasanPage({super.key});

  @override
  State<UlasanPage> createState() => _UlasanPageState();
}

class _UlasanPageState extends State<UlasanPage> {
  List _ulasanList = [];
  bool _isLoading = true;

  Future<void> fetchUlasan() async {
    try {
      final response = await http.get(
        Uri.parse(
          'http://zaa.fortunis11.com/NatureNest-API/API-Ulasan/get_reviews.php',
        ),
      );
      if (response.statusCode == 200) {
        setState(() {
          _ulasanList = json.decode(response.body);
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint("Error fetch ulasan: $e");
    }
  }

  Future<void> deleteUlasan(String id) async {
    final res = await http.post(
      Uri.parse(
        'http://zaa.fortunis11.com/NatureNest-API/API-Ulasan/delete_review.php',
      ),
      body: {'id': id},
    );

    if (res.statusCode == 200) {
      fetchUlasan();
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Ulasan berhasil dihapus")));
    }
  }

  void _showDetail(String id) async {
    try {
      final response = await http.post(
        Uri.parse(
          'http://zaa.fortunis11.com/NatureNest-API/API-Ulasan/get_review_detail.php',
        ),
        body: {'id': id},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'error') {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['message'] ?? "Gagal memuat detail")),
          );
          return;
        }

        showDialog(
          context: context,
          builder:
              (context) => AlertDialog(
                title: Text(data['user_name'] ?? "Tidak diketahui"),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Ulasan: ${data['comment'] ?? 'Tidak ada'}"),
                    const SizedBox(height: 8),
                    Text("Rating: ${data['rating'] ?? '0'} ⭐"),
                    const SizedBox(height: 8),
                    Text("Tanggal: ${data['created_at'] ?? '-'}"),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("Tutup"),
                  ),
                ],
              ),
        );
      }
    } catch (e) {
      debugPrint("Gagal load detail: $e");
    }
  }

  void _showForm({String? id, String? initialText, int? initialRating}) {
    final TextEditingController _controller = TextEditingController(
      text: initialText ?? "",
    );
    int _selectedRating = initialRating ?? 5;

    showDialog(
      context: context,
      builder:
          (context) => StatefulBuilder(
            builder:
                (context, setState) => AlertDialog(
                  title: Text(
                    id == null ? "Tambah Ulasan" : "Edit Ulasan",
                    style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
                  ),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: _controller,
                        maxLines: 5,
                        decoration: const InputDecoration(
                          hintText: "Tulis ulasan di sini",
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text("Rating"),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(5, (index) {
                          return IconButton(
                            icon: Icon(
                              Icons.star,
                              color:
                                  index < _selectedRating
                                      ? Colors.amber
                                      : Colors.grey,
                            ),
                            onPressed: () {
                              setState(() => _selectedRating = index + 1);
                            },
                          );
                        }),
                      ),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("Batal"),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        if (_controller.text.isNotEmpty) {
                          final url =
                              id == null
                                  ? 'http://zaa.fortunis11.com/NatureNest-API/API-Ulasan/create_review.php'
                                  : 'http://zaa.fortunis11.com/NatureNest-API/API-Ulasan/update_review.php';

                          try {
                            final prefs = await SharedPreferences.getInstance();
                            final userId = prefs.getString('id') ?? '';
                            final response = await http.post(
                              Uri.parse(url),
                              body:
                                  id == null
                                      ? {
                                        'user_id': userId,
                                        'comment': _controller.text,
                                        'rating': _selectedRating.toString(),
                                      }
                                      : {
                                        'id': id,
                                        'comment': _controller.text,
                                        'rating': _selectedRating.toString(),
                                      },
                            );

                            final res = json.decode(response.body);
                            if (res['status'] == 'success') {
                              Navigator.pop(context);
                              fetchUlasan();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    id == null
                                        ? "Ulasan ditambahkan"
                                        : "Ulasan diperbarui",
                                  ),
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text("Gagal: ${res['message']}"),
                                ),
                              );
                            }
                          } catch (e) {
                            debugPrint("Error simpan ulasan: $e");
                          }
                        }
                      },
                      child: const Text("Simpan"),
                    ),
                  ],
                ),
          ),
    );
  }

  @override
  void initState() {
    super.initState();
    fetchUlasan();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF2EA),
      appBar: AppBar(
        title: Text(
          "Ulasan Pengguna",
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF8F957B),
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        ),
        actions: [
          IconButton(
            onPressed: () => _showForm(),
            icon: const Icon(Icons.add, color: Colors.white),
          ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                itemCount: _ulasanList.length,
                padding: const EdgeInsets.all(16),
                itemBuilder: (context, index) {
                  final ulasan = _ulasanList[index];
                  return GestureDetector(
                    onTap: () => _showDetail(ulasan['id'].toString()),
                    child: GlassCard(
                      name: ulasan['user_name'] ?? 'Anonim',
                      review: ulasan['comment'] ?? '-',
                      date: ulasan['created_at'] ?? '',
                      rating: int.tryParse(ulasan['rating'] ?? '0') ?? 0, // ✅ Tambahkan ini
                      onEdit:
                          () => _showForm(
                            id: ulasan['id'].toString(),
                            initialText: ulasan['comment'],
                            initialRating: int.tryParse(
                              ulasan['rating'] ?? '5',
                            ),
                          ),
                      onDelete: () {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: const Text("Hapus Ulasan"),
                            content: const Text("Apakah kamu yakin ingin menghapus ulasan ini?"),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text("Batal"),
                              ),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.redAccent,
                                ),
                                onPressed: () {
                                  Navigator.pop(context); // Tutup dialog dulu
                                  deleteUlasan(ulasan['id'].toString()); // Lanjut hapus
                                },
                                child: const Text("Ya, Hapus"),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final String name;
  final String review;
  final String date;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final int rating;

  const GlassCard({
    super.key,
    required this.name,
    required this.review,
    required this.date,
    required this.onEdit,
    required this.onDelete,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.93),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Nama dan action icon
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.person, size: 18, color: Color(0xFF344E41)),
                  const SizedBox(width: 6),
                  Text(
                    name,
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: const Color(0xFF344E41),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit, color: Color(0xFF588157)),
                    onPressed: onEdit,
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.redAccent),
                    onPressed: onDelete,
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 6),

          // Rating bintang
          Row(
            children: List.generate(5, (index) {
              return Icon(
                index < rating ? Icons.star : Icons.star_border,
                size: 20,
                color: Colors.amber,
              );
            }),
          ),

          const SizedBox(height: 12),

          // Label
          Text(
            "Komentar",
            style: GoogleFonts.poppins(
              fontSize: 13.5,
              fontWeight: FontWeight.w500,
              color: const Color(0xFF344E41),
            ),
          ),
          const SizedBox(height: 4),

          // Isi review
          Text(
            review,
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey[800],
              height: 1.4,
            ),
          ),

          const SizedBox(height: 10),

          // Tanggal
          Row(
            children: [
              const Icon(Icons.calendar_today, size: 14, color: Color(0xFF6c757d)),
              const SizedBox(width: 6),
              Text(
                date.isNotEmpty
                    ? DateFormat("dd MMM yyyy").format(DateTime.parse(date))
                    : "-",
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey[600],
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

