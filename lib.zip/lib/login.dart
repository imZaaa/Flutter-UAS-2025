// Import bawaan untuk efek blur dan UI
import 'dart:ui';
import 'package:flutter/material.dart';

// Import HTTP untuk koneksi ke server API
import 'package:http/http.dart' as http;

// JSON decode untuk parsing data dari API
import 'dart:convert';

// SharedPreferences untuk menyimpan data user secara lokal
import 'package:shared_preferences/shared_preferences.dart';

// Impor halaman tujuan setelah login berhasil
import 'home.dart';

class LoginRegisterPage extends StatefulWidget {
  const LoginRegisterPage({super.key});

  @override
  State<LoginRegisterPage> createState() => _LoginRegisterPageState();
}

class _LoginRegisterPageState extends State<LoginRegisterPage> {
  // Mode halaman: true = login, false = register
  bool isLogin = true;

  // Kunci untuk validasi form
  final _formKey = GlobalKey<FormState>();

  // Controller untuk menangkap input pengguna
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  // URL API backend
  final String baseUrl = 'http://zaa.fortunis11.com/NatureNest-API';

  // Fungsi submit (login atau register)
  Future<void> submit() async {
    // Jika form tidak valid, hentikan
    if (!_formKey.currentState!.validate()) return;

    // Tentukan endpoint API berdasarkan mode
    String url = isLogin
        ? '$baseUrl/API-Users/login.php'
        : '$baseUrl/API-Users/register.php';

    // Data yang dikirim
    final body = {
      'name': nameController.text,
      'password': passwordController.text,
      if (!isLogin) 'email': emailController.text,
    };

    try {
      // Kirim POST request ke API
      var response = await http.post(Uri.parse(url), body: body);

      // Ubah response JSON ke map
      final data = json.decode(response.body);
      print('RESPON SERVER: $data'); // Debug log

      // Jika status sukses
      if (data['status'] == 'success') {
        // Tampilkan pesan berhasil
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Berhasil ${isLogin ? 'login' : 'registrasi'}')),
        );

        // Jika login dan data user tersedia
        if (isLogin && data['user'] != null) {
          final prefs = await SharedPreferences.getInstance();
          final user = data['user'];

          // Simpan data user ke lokal
          await prefs.setString('id', user['id'].toString());
          await prefs.setString('user_id', user['id'].toString());
          await prefs.setString('username', user['name']);
          await prefs.setString('email', user['email']);

          // Navigasi ke halaman utama
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const HomePage()),
          );
        }

        // Jika registrasi, kosongkan input dan ubah ke mode login
        if (!isLogin) {
          setState(() {
            isLogin = true;
            nameController.clear();
            emailController.clear();
            passwordController.clear();
          });
        }
      } else {
        // Jika gagal, tampilkan pesan dari server
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'] ?? 'Terjadi kesalahan')),
        );
      }
    } catch (e) {
      // Jika tidak bisa konek ke server
      print("LOGIN ERROR: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gagal terhubung ke server')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Warna utama tema tombol
    Color themeColor = const Color(0xFF8F957B);

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Latar belakang berupa gambar hutan
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/hutan.jpeg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Lapisan blur agar efek glass
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(color: Colors.black.withOpacity(0.3)),
          ),
          // Form login/register
          Center(
            child: Container(
              padding: const EdgeInsets.all(20),
              margin: const EdgeInsets.symmetric(horizontal: 24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.15), // Efek transparan
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withOpacity(0.2)),
              ),
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      // Judul halaman: Login atau Register
                      Text(
                        isLogin ? 'Login' : 'Register',
                        style: const TextStyle(
                          fontSize: 28,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Input username
                      _glassInputField(
                        controller: nameController,
                        hintText: 'Username',
                        icon: Icons.person,
                        validator: (value) =>
                            value!.isEmpty ? 'Username wajib diisi' : null,
                      ),

                      // Input email (hanya jika register)
                      if (!isLogin)
                        _glassInputField(
                          controller: emailController,
                          hintText: 'Email',
                          icon: Icons.email,
                          validator: (value) {
                            if (isLogin) return null;
                            if (value == null || value.isEmpty) {
                              return 'Email wajib diisi';
                            } else if (!value.contains('@')) {
                              return 'Format email tidak valid';
                            }
                            return null;
                          },
                        ),

                      // Input password
                      _glassInputField(
                        controller: passwordController,
                        hintText: 'Password',
                        icon: Icons.lock,
                        obscureText: true,
                        validator: (value) =>
                            value == null || value.length < 6
                                ? 'Minimal 6 karakter'
                                : null,
                      ),

                      const SizedBox(height: 20),

                      // Tombol login/register
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: themeColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 40,
                            vertical: 14,
                          ),
                        ),
                        onPressed: submit,
                        child: Text(
                          isLogin ? 'Login' : 'Register',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                          ),
                        ),
                      ),

                      // Tombol switch mode login/register
                      TextButton(
                        onPressed: () {
                          setState(() => isLogin = !isLogin);
                        },
                        child: Text(
                          isLogin
                              ? 'Belum punya akun? Register'
                              : 'Sudah punya akun? Login',
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget reusable untuk input field dengan gaya glassmorphism
  Widget _glassInputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    bool obscureText = false,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        obscureText: obscureText,
        validator: validator,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white.withOpacity(0.1),
          prefixIcon: Icon(icon, color: Colors.white),
          hintText: hintText,
          hintStyle: const TextStyle(color: Colors.white70),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
