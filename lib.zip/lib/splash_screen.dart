// Import package Flutter bawaan
import 'package:flutter/material.dart'; // 📦 Untuk bikin UI dengan widget

// Import bawaan Dart
import 'dart:async'; // ⏱️ Untuk fungsi Timer

// Import halaman login yang akan dituju setelah splash
import 'login.dart'; // 📄 File tujuan setelah splash selesai

// Widget Stateful karena akan ada perubahan state (navigasi setelah delay)
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState(); // Membuat dan menghubungkan state
}

// Kelas State untuk SplashScreen
class _SplashScreenState extends State<SplashScreen> {

  // Method yang dijalankan pertama kali saat widget ini aktif
  @override
  void initState() {
    super.initState(); // Panggil init bawaan
    
    // Timer 5 detik -> setelah itu navigasi ke LoginRegisterPage
    Timer(Duration(seconds: 5), () {
      Navigator.pushReplacement( // ⏩ Ganti halaman tanpa bisa balik ke splash
        context,
        MaterialPageRoute(builder: (context) => LoginRegisterPage()), // Tuju ke LoginRegisterPage
      );
    });
  }

  // Tampilan splash screen
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF201E1E), // 🎨 Warna gelap, sesuai mood elegan

      // Isi halaman splash
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // 📍 Tengah secara vertikal
          children: [
            // Gambar logo aplikasi
            Image.asset(
              'assets/logo.png', // 🖼️ Path gambar logo di folder assets
              width: 200, // 📏 Lebar gambar
              height: 200, // 📏 Tinggi gambar
            ),

            SizedBox(height: 20), // 🧱 Spacer: jarak antara gambar dan teks

            // Teks sambutan
            Text(
              'Welcome to NatureFest...',
              style: TextStyle(
                fontSize: 28, // 🔠 Ukuran font besar
                fontWeight: FontWeight.bold, // 🅱️ Teks tebal
                color: Colors.white, // 🌕 Warna putih agar kontras
                letterSpacing: 1.5, // ↔️ Spasi antar huruf
              ),
            ),

            SizedBox(height: 10), // 🧱 Spacer: jarak ke bawah

            // Indikator loading (animasi)
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white), // 🔄 Warna loading putih
            ),
          ],
        ),
      ),
    );
  }
}