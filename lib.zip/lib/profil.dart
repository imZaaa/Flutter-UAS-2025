import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';

class ProfilPage extends StatefulWidget {
  const ProfilPage({super.key});

  @override
  State<ProfilPage> createState() => _ProfilPageState();
}

class _ProfilPageState extends State<ProfilPage> {
  String? id;
  String? name;
  String? email;
  String? createdAt;
  bool isLoading = true;

  final String baseUrl = 'http://zaa.fortunis11.com/NatureNest-API';

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  Future<void> loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    id = prefs.getString('id');

    if (id != null) {
      try {
        final res = await http.get(
          Uri.parse('$baseUrl/API-Users/get_user.php?id=$id'),
        );
        final data = json.decode(res.body);

        if (data['status'] == 'success') {
          final user = data['user'];
          final created = DateTime.tryParse(user['created_at'] ?? '');
          final formattedDate = created != null
              ? DateFormat("d MMMM yyyy", 'id_ID').format(created)
              : '-';

          setState(() {
            name = user['name'] ?? '-';
            email = user['email'] ?? '-';
            createdAt = formattedDate;
            isLoading = false;
          });
        }
      } catch (_) {
        setState(() => isLoading = false);
      }
    } else {
      setState(() => isLoading = false);
    }
  }

  void showEditProfileDialog() {
    final nameController = TextEditingController(text: name);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Username'),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(labelText: 'Username Baru'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.isNotEmpty) {
                final res = await http.post(
                  Uri.parse('$baseUrl/API-Users/edit.php'),
                  body: {'id': id!, 'name': nameController.text},
                );
                final data = json.decode(res.body);
                if (data['status'] == 'success') {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setString('username', nameController.text);
                  setState(() => name = nameController.text);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Username berhasil diperbarui')),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void showChangePasswordDialog() {
    final oldPass = TextEditingController();
    final newPass = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ganti Password'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: oldPass,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password Lama'),
            ),
            TextField(
              controller: newPass,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Password Baru'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              if (oldPass.text.isEmpty || newPass.text.length < 6) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Password tidak valid')),
                );
                return;
              }
              final res = await http.post(
                Uri.parse('$baseUrl/API-Users/edit.php'),
                body: {
                  'id': id!,
                  'old_password': oldPass.text,
                  'new_password': newPass.text,
                },
              );
              final data = json.decode(res.body);
              if (data['status'] == 'success') {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Password berhasil diganti')),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(data['message'] ?? 'Gagal mengganti password')),
                );
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const Color themeColor = Color(0xFF8F957B);

    return Scaffold(
      backgroundColor: const Color(0xFFEFF2EA),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF8F957B)))
          : Column(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    color: themeColor,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                  ),
                  padding: const EdgeInsets.only(top: 60, bottom: 30),
                  width: double.infinity,
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 10,
                              offset: Offset(0, 6),
                            ),
                          ],
                        ),
                        child: const CircleAvatar(
                          radius: 50,
                          backgroundImage: AssetImage('assets/default_user.png'),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        name ?? '-',
                        style: GoogleFonts.poppins(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        email ?? '-',
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
                    child: Column(
                      children: [
                        _infoTile(Icons.calendar_today, "Bergabung sejak", createdAt),
                        const SizedBox(height: 20),
                        _actionButton(Icons.edit, "Edit Username", showEditProfileDialog),
                        const SizedBox(height: 14),
                        _actionButton(Icons.lock, "Ganti Password", showChangePasswordDialog),
                        const SizedBox(height: 30),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.logout),
                          label: const Text("Keluar"),
                          onPressed: () async {
                            final prefs = await SharedPreferences.getInstance();
                            await prefs.clear();
                            if (!mounted) return;
                            Navigator.pushReplacementNamed(context, '/login');
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _infoTile(IconData icon, String label, String? value) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFF8F957B), size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            "$label: ${value ?? '-'}",
            style: GoogleFonts.poppins(fontSize: 15, color: Colors.black87),
          ),
        ),
      ],
    );
  }

  Widget _actionButton(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFF8F957B).withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: const Color(0xFF8F957B)),
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
