// Import library yang dibutuhkan
import 'dart:convert'; // Untuk mengubah JSON ke objek Dart
import 'package:flutter/material.dart'; // UI dasar Flutter
import 'package:google_fonts/google_fonts.dart'; // Gunakan font dari Google Fonts
import 'package:http/http.dart' as http; // Untuk melakukan HTTP request ke API
import 'package:shared_preferences/shared_preferences.dart'; // Akses data lokal (seperti user_id)
import 'package:intl/intl.dart'; // Untuk format tanggal
import 'destinasi_page.dart'; // Import model & class DestinasiModel

// Halaman wishlist
class WishlistPage extends StatefulWidget {
  const WishlistPage({super.key});

  @override
  State<WishlistPage> createState() => _WishlistPageState();
}

class _WishlistPageState extends State<WishlistPage> {
  List<Map<String, dynamic>> wishlist = []; // Menyimpan data wishlist dari API
  List<DestinasiModel> destinasiList = []; // Menyimpan data destinasi dari API
  bool isLoading = true; // Indikator loading

  @override
  void initState() {
    super.initState();
    loadWishlistData(); // Panggil fungsi saat pertama dibuka
  }

  // Load semua data: wishlist dan destinasi
  Future<void> loadWishlistData() async {
    setState(() => isLoading = true); // Set loading
    await Future.wait([
      fetchWishlist(), // Ambil wishlist user
      fetchDestinasiList(), // Ambil daftar destinasi
    ]);
    setState(() => isLoading = false); // Selesai loading
  }

  // Ambil data wishlist user dari server
  Future<void> fetchWishlist() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('user_id'); // Ambil user_id dari local storage

    if (userId == null) {
      print('❌ user_id kosong');
      wishlist.clear();
      return;
    }

    final url = Uri.parse(
        'http://zaa.fortunis11.com/NatureNest-API/API-Wishlist/get_wishlist.php?user_id=$userId');

    try {
      final response = await http.get(url);
      print('📦 Response Wishlist (${response.statusCode}): ${response.body}');

      wishlist.clear(); // Reset data dulu

      if (response.statusCode == 200) {
        final decoded = json.decode(response.body);

        if (decoded is List) {
          wishlist = List<Map<String, dynamic>>.from(decoded); // Ubah ke list Map
          print('✅ Wishlist dimuat: ${wishlist.length} item');
        } else {
          print('⚠️ Respon bukan list');
        }
      } else {
        print('⚠️ Gagal fetch wishlist. Status: ${response.statusCode}');
      }
    } catch (e) {
      print('❌ Error saat ambil wishlist: $e');
      wishlist.clear();
    }
  }

  // Ambil semua data destinasi dari API
  Future<void> fetchDestinasiList() async {
    final url = Uri.parse(
        'http://zaa.fortunis11.com/NatureNest-API/API-Destinasi/get_destinasi.php');

    try {
      final response = await http.get(url);
      print('📦 Response Destinasi (${response.statusCode}): ${response.body}');

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        destinasiList = data.map((e) => DestinasiModel.fromJson(e)).toList(); // Convert ke model
        print('✅ Destinasi dimuat: ${destinasiList.length} item');
      } else {
        print('⚠️ Gagal fetch destinasi');
      }
    } catch (e) {
      print('❌ Error saat ambil destinasi: $e');
    }
  }

  // Fungsi hapus wishlist dari server
  Future<void> deleteWishlistItem(int id) async {
    final url = Uri.parse(
        'http://zaa.fortunis11.com/NatureNest-API/API-Wishlist/delete_wishlist.php');
    final response = await http.post(url, body: {'id': id.toString()});
    print('🗑 Hapus item ID $id → status ${response.statusCode}');
    if (response.statusCode == 200) {
      await loadWishlistData(); // Refresh data
    }
  }

  // Fungsi tandai sebagai sudah dikunjungi
  Future<void> markVisited(int id) async {
    final url = Uri.parse(
        'http://zaa.fortunis11.com/NatureNest-API/API-Wishlist/update_wishlist.php');
    final response = await http.post(url, body: {
      'id': id.toString(),
      'visited': '1', // Tandai sebagai sudah dikunjungi
    });
    print('📌 Tandai visited ID $id → status ${response.statusCode}');
    if (response.statusCode == 200) {
      await loadWishlistData(); // Refresh data
    }
  }

  // Format tanggal dari string ke format tanggal lokal
  String formatTanggal(String rawDate) {
    try {
      final DateTime dateTime = DateTime.parse(rawDate); // Convert string ke DateTime
      return DateFormat('d MMMM yyyy', 'id_ID').format(dateTime); // Format Indonesia
    } catch (e) {
      return rawDate; // Kalau gagal, tampilkan apa adanya
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF2EA), // Warna latar
      appBar: AppBar(
        title: Text(
          'Wishlist Saya',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFF8F957B),
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator()) // Loading saat fetch data
          : wishlist.isEmpty
              ? Center(
                  child: Text(
                    'Wishlist kamu masih kosong 😕',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: const Color(0xFF344E41),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: wishlist.length,
                  itemBuilder: (context, index) {
                    final item = wishlist[index]; // Ambil item wishlist

                    final destinasi = destinasiList.firstWhere(
                      (d) => d.id.toString() == item['destination_id'].toString(),
                      orElse: () {
                        // Jika data destinasi tidak ditemukan
                        print('⚠️ Tidak menemukan destinasi dengan ID ${item['destination_id']}');
                        return DestinasiModel(
                          id: 0,
                          nama: 'Tidak Ditemukan',
                          deskripsi: '',
                          gambar: 'assets/images/not_found.jpg',
                          kategori: '',
                        );
                      },
                    );

                    final isOnlineImage = destinasi.gambar.startsWith('http');

                    // Kartu tampilan wishlist
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.08),
                            blurRadius: 16,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(24),
                              bottomLeft: Radius.circular(24),
                            ),
                            child: isOnlineImage
                                ? Image.network(destinasi.gambar, width: 120, height: 120, fit: BoxFit.cover)
                                : Image.asset(destinasi.gambar, width: 120, height: 120, fit: BoxFit.cover),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // Baris judul + menu
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          destinasi.nama,
                                          style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                            color: const Color(0xFF344E41),
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      PopupMenuButton<String>(
                                        color: Colors.white,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        onSelected: (value) {
                                          if (value == 'visited') {
                                            markVisited(int.parse(item['id'].toString()));
                                          } else if (value == 'delete') {
                                            deleteWishlistItem(int.parse(item['id'].toString()));
                                          }
                                        },
                                        itemBuilder: (context) => const [
                                          PopupMenuItem(
                                            value: 'visited',
                                            child: Text('Sudah dikunjungi'),
                                          ),
                                          PopupMenuItem(
                                            value: 'delete',
                                            child: Text('Hapus'),
                                          ),
                                        ],
                                        icon: const Icon(Icons.more_vert, color: Color(0xFF344E41)),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  // Catatan atau status visited
                                  Text(
                                    item['visited'] == '1'
                                        ? '✅ Sudah dikunjungi'
                                        : (item['note'] ?? destinasi.deskripsi),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.poppins(
                                      fontSize: 13.5,
                                      fontStyle: item['visited'] == '1'
                                          ? FontStyle.italic
                                          : FontStyle.normal,
                                      color: item['visited'] == '1'
                                          ? Colors.green[700]
                                          : Colors.grey[800],
                                    ),
                                  ),
                                  // Tanggal ditambahkan
                                  if (item['created_at'] != null)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 6.0),
                                      child: Text(
                                        'Ditambahkan: ${formatTanggal(item['created_at'])}',
                                        style: GoogleFonts.poppins(
                                          fontSize: 11.5,
                                          color: const Color(0xFF588157),
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}