import 'dart:convert'; // Untuk decode data JSON dari API cuaca
import 'dart:ui'; // Untuk efek blur (glassmorphism)
import 'package:flutter/material.dart'; // Komponen UI Flutter
import 'package:google_fonts/google_fonts.dart'; // Paket font Google
import 'package:shared_preferences/shared_preferences.dart'; // Menyimpan/ambil data user lokal
import 'package:http/http.dart' as http; // Untuk koneksi ke API
import 'package:geolocator/geolocator.dart'; // Untuk ambil lokasi user

import 'destinasi_page.dart'; // Halaman destinasi wisata
import 'wishlist.dart'; // Halaman wishlist user
import 'ulasan_page.dart'; // Halaman ulasan pengguna
import 'profil.dart'; // Halaman profil user

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String nama = "User"; // Nama user yang ditampilkan di home
  int _selectedIndex = 0; // Index tab navigation aktif
  String _weatherDescription = ''; // Deskripsi cuaca
  String _temperature = ''; // Suhu dalam °C

  // Data dummy destinasi untuk ditampilkan sebagai rekomendasi
  final List<Map<String, String>> destinasiWisata = [
    {
      'nama': 'Pantai Kuta',
      'deskripsi': 'Pantai terkenal di Bali dengan pasir putih yang lembut...',
      'gambar': 'assets/kuta.jpeg',
    },
    {
      'nama': 'Gunung Bromo',
      'deskripsi': 'Gunung berapi aktif di Jawa Timur dengan sunrise menawan...',
      'gambar': 'assets/bromo.jpeg',
    },
    {
      'nama': 'Danau Toba',
      'deskripsi': 'Danau vulkanik terbesar di dunia di Sumatera Utara...',
      'gambar': 'assets/toba.jpeg',
    },
    {
      'nama': 'Candi Borobudur',
      'deskripsi': 'Candi Buddha terbesar di dunia dengan relief megah...',
      'gambar': 'assets/borobudur.jpeg',
    },
  ];

  @override
  void initState() {
    super.initState();
    loadUserName(); // Ambil nama user dari SharedPreferences
    _getWeather(); // Ambil data cuaca berdasarkan lokasi
  }

  // Fungsi untuk ambil nama user dari penyimpanan lokal
  Future<void> loadUserName() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      nama = prefs.getString('username') ?? 'User';
    });
  }

  // Fungsi untuk ambil data cuaca dari OpenWeather API
  Future<void> _getWeather() async {
    try {
      // Minta izin akses lokasi
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        permission = await Geolocator.requestPermission();
      }

      // Dapatkan koordinat lokasi user
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      final lat = position.latitude;
      final lon = position.longitude;

      // API key OpenWeather (harus kamu simpan aman di produksi)
      const apiKey = '31065fa45b20e9517e681bc89b128017';
      final url = Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric',
      );

      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _weatherDescription = data['weather'][0]['main'];
          _temperature = "${data['main']['temp'].toStringAsFixed(0)}°C";
        });
      }
    } catch (e) {
      print('Gagal ambil data cuaca: $e'); // Error jika gagal
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true, // Untuk efek transparan di bawah
      backgroundColor: const Color(0xFF8F957B), // Warna latar belakang utama
      bottomNavigationBar: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20), // Bikin sudut atas melengkung
          topRight: Radius.circular(20),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10), // Efek blur navigasi
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            backgroundColor: Colors.black.withOpacity(0.2), // Transparan
            selectedItemColor: Colors.white, // Warna menu aktif
            unselectedItemColor: Colors.white60,
            currentIndex: _selectedIndex, // Tab yang aktif
            onTap: (index) {
              setState(() => _selectedIndex = index);
              if (index == 0) loadUserName(); // Update nama saat kembali ke Home
            },
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
              BottomNavigationBarItem(icon: Icon(Icons.explore), label: 'Destinasi'),
              BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Wishlist'),
              BottomNavigationBarItem(icon: Icon(Icons.info), label: 'Ulasan'),
              BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
            ],
          ),
        ),
      ),
      body: IndexedStack(
        index: _selectedIndex, // Tampilkan tab sesuai index
        children: [
          buildBeranda(), // Halaman utama
          const DestinasiPage(),
          _selectedIndex == 2 ? WishlistPage(key: UniqueKey()) : const SizedBox(),
          const UlasanPage(),
          const ProfilPage(),
        ],
      ),
    );
  }

  // Widget untuk halaman Home (Beranda)
  Widget buildBeranda() {
    return Column(
      children: [
        SafeArea(
          bottom: false,
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
            decoration: const BoxDecoration(
              color: Color(0xFF8F957B),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Menampilkan info cuaca jika sudah ada datanya
                if (_temperature.isNotEmpty)
                  Row(
                    children: [
                      const Icon(Icons.wb_sunny, color: Colors.amber, size: 24),
                      const SizedBox(width: 8),
                      Text(
                        "$_temperature • $_weatherDescription",
                        style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
                      ),
                    ],
                  ),
                const SizedBox(height: 12),
                Text(
                  "Selamat Datang, $nama 👋",
                  style: GoogleFonts.poppins(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Yuk, mulai petualangan alammu!",
                  style: GoogleFonts.poppins(fontSize: 14, color: Colors.white70),
                ),
                const SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const TextField(
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Cari tempat wisata...',
                      hintStyle: TextStyle(color: Colors.white54),
                      prefixIcon: Icon(Icons.search, color: Colors.white),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
                bottomLeft: Radius.circular(16),
                bottomRight: Radius.circular(16),
              ),
            ),
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: ListView(
              children: [
                SizedBox(
                  height: 70,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _buildCategory("Camping", Icons.park),
                      _buildCategory("Trekking", Icons.directions_walk),
                      _buildCategory("Climbing", Icons.terrain),
                      _buildCategory("Hiking", Icons.nordic_walking),
                      _buildCategory("Pro", Icons.local_fire_department),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  "Rekomendasi untuk kamu",
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 12),
                GridView.builder(
                  itemCount: destinasiWisata.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.75,
                  ),
                  itemBuilder: (context, index) {
                    final item = destinasiWisata[index];
                    return Material(
                      color: const Color(0xFFE4ECEB),
                      elevation: 6,
                      shadowColor: Colors.black26,
                      borderRadius: BorderRadius.circular(20),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () {
                          // Aksi saat kartu destinasi ditekan
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.black12),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Image.asset(
                                  item['gambar']!,
                                  height: 110,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    item['nama']!,
                                    style: GoogleFonts.poppins(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                      color: Colors.black87,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 8),
                                  child: Text(
                                    item['deskripsi']!,
                                    maxLines: 3,
                                    overflow: TextOverflow.ellipsis,
                                    style: GoogleFonts.poppins(
                                      fontSize: 12,
                                      color: Colors.black54,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Widget untuk kategori horizontal di atas daftar destinasi
  Widget _buildCategory(String label, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(right: 22),
      child: Column(
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: Colors.black12,
            child: Icon(icon, size: 25, color: Colors.black87),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 10, color: Colors.black)),
        ],
      ),
    );
  }
}
