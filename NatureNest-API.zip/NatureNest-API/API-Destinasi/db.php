<?php
$host = "localhost";
$user = "fore6986_NatureNest";
$pass = "Ezagg123";
$db   = "fore6986_NatureNest";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}