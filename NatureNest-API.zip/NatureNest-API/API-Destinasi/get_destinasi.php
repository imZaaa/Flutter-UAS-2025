<?php
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$sql = "SELECT * FROM destinasi";
$result = $conn->query($sql);

$data = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Sanitize data agar tidak error saat json_encode
        foreach ($row as $key => $val) {
            $row[$key] = htmlspecialchars($val, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        }

        $data[] = $row;
    }

    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
} else {
    echo json_encode(["error" => $conn->error]);
}
?>
