<?php
require 'db.php';
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
$conn->query($sql);
echo json_encode(["status" => "success", "message" => "User registered"]);
?>