<?php
require 'db.php';
$id = $_POST['id'];
$sql = "DELETE FROM users WHERE id='$id'";
$conn->query($sql);
echo json_encode(["status" => "success", "message" => "User deleted"]);
?>