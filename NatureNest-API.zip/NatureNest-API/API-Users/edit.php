<?php
require 'db.php';

$id = $_POST['id'] ?? null;
$new_name = $_POST['name'] ?? null;
$old_password = $_POST['old_password'] ?? null;
$new_password = $_POST['new_password'] ?? null;

if (!$id) {
    echo json_encode(['status' => 'error', 'message' => 'ID tidak ditemukan']);
    exit;
}

// Update username jika `name` tersedia
if ($new_name) {
    $stmt = $conn->prepare("UPDATE users SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $new_name, $id);

    if ($stmt->execute()) {
        $response['update_name'] = 'success';
    } else {
        $response['update_name'] = 'error';
        $response['message_name'] = 'Gagal memperbarui username';
    }
    $stmt->close();
}

// Ganti password jika `old_password` dan `new_password` tersedia
if ($old_password && $new_password) {
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        echo json_encode(['status' => 'error', 'message' => 'User tidak ditemukan']);
        exit;
    }

    if ($user['password'] !== $old_password) {
        echo json_encode(['status' => 'error', 'message' => 'Password lama tidak cocok']);
        exit;
    }

    $stmt->close();

    // Update password
    $stmtUpdate = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmtUpdate->bind_param("si", $new_password, $id);

    if ($stmtUpdate->execute()) {
        $response['update_password'] = 'success';
    } else {
        $response['update_password'] = 'error';
        $response['message_password'] = 'Gagal mengganti password';
    }

    $stmtUpdate->close();
}

// Kirim respon akhir
$response['status'] = 'success';
echo json_encode($response);
$conn->close();
