<?php
require 'db.php';

$id = $_POST['id'];

$sql = "DELETE FROM wishlist WHERE id = '$id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>
