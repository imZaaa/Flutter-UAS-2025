<?php
require 'db.php';

$user_id = $_POST['user_id'];
$destination_id = $_POST['destination_id'];
$note = $_POST['note'];
$visited = isset($_POST['visited']) ? $_POST['visited'] : 0;

$sql = "INSERT INTO wishlist (user_id, destination_id, note, visited) VALUES ('$user_id', '$destination_id', '$note', '$visited')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>
