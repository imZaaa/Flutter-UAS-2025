<?php
require 'db.php';

$user_id = $_GET['user_id'];

if (!$user_id) {
    echo json_encode([]);
    exit;
}

$sql = "SELECT 
            wishlist.id AS id,
            wishlist.user_id,
            wishlist.destination_id,
            wishlist.note,
            wishlist.visited,
            wishlist.created_at,
            destinasi.nama,
            destinasi.deskripsi,
            destinasi.gambar,
            destinasi.kategori
        FROM wishlist
        JOIN destinasi ON wishlist.destination_id = destinasi.id
        WHERE wishlist.user_id = '$user_id'
        ORDER BY wishlist.id DESC";

$result = $conn->query($sql);

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
?>
