<?php
$host = "localhost";
$user = "fore6986_NatureNest"; // ganti sesuai cPanel
$pass = "Ezagg123";     // ganti sesuai password
$db   = "fore6986_NatureNest"; // nama database kamu

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>