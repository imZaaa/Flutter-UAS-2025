<?php
require 'db.php';

$id = $_POST['id'];
$visited = $_POST['visited'];

$sql = "UPDATE wishlist SET visited = '$visited' WHERE id = '$id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>
