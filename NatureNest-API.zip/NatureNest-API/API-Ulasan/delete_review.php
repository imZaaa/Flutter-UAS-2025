<?php
require 'db.php';

$id = $_POST['id'];

$sql = "DELETE FROM reviews WHERE id = '$id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Ulasan berhasil dihapus"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>