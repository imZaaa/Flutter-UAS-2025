<?php
require 'db.php';

$id = $_POST['id'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];

$sql = "UPDATE reviews SET rating='$rating', comment='$comment' WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Ulasan berhasil diupdate"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>