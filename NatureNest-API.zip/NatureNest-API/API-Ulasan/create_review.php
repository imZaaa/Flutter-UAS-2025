<?php
require 'db.php';

$user_id = $_POST['user_id'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];

$sql = "INSERT INTO reviews (user_id, rating, comment) VALUES ('$user_id', '$rating', '$comment')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Ulasan berhasil ditambahkan"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>