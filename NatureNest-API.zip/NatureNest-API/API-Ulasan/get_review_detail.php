<?php
require 'db.php';

$id = $_POST['id']; // pakai POST karena di Flutter kamu kirim pakai POST

$sql = "SELECT r.*, u.name AS user_name
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        WHERE r.id = '$id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo json_encode($result->fetch_assoc());
} else {
    echo json_encode(["status" => "error", "message" => "Ulasan tidak ditemukan"]);
}
?>
