<?php
require 'db.php';

$sql = "SELECT reviews.*, users.name AS user_name 
FROM reviews 
LEFT JOIN users ON reviews.user_id = users.id
ORDER BY reviews.created_at DESC";

$result = $conn->query($sql);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
?>
